from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

app = Flask(__name__)

# Load the pre-trained model
model = load_model("../noisy_signal_classifier.h5")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect', methods=['POST'])
def detect_noise():
    try:
        # Check if a file is uploaded
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']

        # Ensure the file is a CSV
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'Invalid file type. Please upload a CSV file.'}), 400
        
        # Read the CSV file into a pandas DataFrame
        data = pd.read_csv(file)

        # Ensure the 'Original Signal' column exists
        if 'Original Signal' not in data.columns:
            return jsonify({'error': "'Original Signal' column not found in the uploaded file."}), 400

        # Extract the signal data
        signal_data = data['Original Signal'].values.reshape(-1, 1)

        # Normalize the signal data
        scaler = MinMaxScaler()
        normalized_signal = scaler.fit_transform(signal_data)

        # Make predictions using the model
        predictions = model.predict(normalized_signal)
        classifications = (predictions > 0.5).astype(int).flatten().tolist()

        # Combine results for easier frontend processing
        results = {
            "time": data.get("Time", []).tolist() if "Time" in data else list(range(len(classifications))),
            "original_signal": data["Original Signal"].tolist(),
            "predictions": classifications
        }

        return jsonify({
            'results': results,
            'message': f"Processed {len(classifications)} signal points successfully."
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
