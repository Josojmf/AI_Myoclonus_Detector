# Graphic Interface for AI Spasticity detector model
## Usage
```
pip install requirements.txt
```
python .\AI_Predictor_Web_Service.py
```

