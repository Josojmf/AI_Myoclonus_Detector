document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.getElementById("sidebar");
    const menuToggle = document.getElementById("menuToggle");
    const fileUploadForm = document.getElementById("fileUploadForm");
    const resultDiv = document.getElementById("result");

    // Toggle sidebar visibility
    menuToggle.addEventListener("click", function () {
        sidebar.classList.toggle("open");
    });

    // Menu items functionality
    document.getElementById("howToUse").addEventListener("click", function () {
        alert("Upload a CSV file with two columns: 'Time' and 'Original Signal'. Only the 'Original Signal' column will be analyzed.");
    });

    document.getElementById("about").addEventListener("click", function () {
        alert("This tool uses a machine learning model to classify noisy and clean segments of an ECG signal.");
    });

    // File upload form submission
    fileUploadForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const fileInput = document.getElementById("fileInput");
        const file = fileInput.files[0];

        if (!file) {
            alert("Please upload a valid CSV file.");
            return;
        }

        const formData = new FormData();
        formData.append("file", file);

        fetch("/detect", {
            method: "POST",
            body: formData,
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.error) {
                    resultDiv.innerText = `Error: ${data.error}`;
                } else {
                    const { results } = data;
                    displayResults(results);
                }
            })
            .catch((error) => {
                console.error("Error:", error);
                resultDiv.innerText = "An error occurred. Please try again.";
            });
    });

    function displayResults(results) {
        const resultDiv = document.getElementById("result");
        resultDiv.innerHTML = ""; // Clear previous results
    
        // Create a table for the results
        const table = document.createElement("table");
        table.className = "result-table";
    
        // Add table header
        const thead = document.createElement("thead");
        thead.innerHTML = `
            <tr>
                <th>Time</th>
                <th>Original Signal</th>
                <th>Prediction</th>
            </tr>
        `;
        table.appendChild(thead);
    
        // Add table body
        const tbody = document.createElement("tbody");
        results.time.forEach((time, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${time}</td>
                <td>${results.original_signal[index]}</td>
                <td>${results.predictions[index]}</td>
            `;
            tbody.appendChild(row);
        });
        table.appendChild(tbody);
    
        resultDiv.appendChild(table);
    }
    
});
